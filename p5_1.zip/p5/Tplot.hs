module Tplot where
import Turtle

getpos :: Turtle -> Position
getpos (_,_,pos,_) = pos
--

step :: Turtle -> Char -> Turtle
step turt s = case s of
   '>' -> moveTurtle turt Forward
   '+' -> moveTurtle turt TurnRight 
   '-' -> moveTurtle turt TurnLeft

--tplot :: Turtle -> [Char] -> [Position]
--tplot turt str = --Probar con las guardas
--   if (not (null str))
--   then
--      getpos turt : tplot (step turt (head str)) (tail str)
--   else []

tplot :: Turtle -> String -> [Position]
tplot tortuga [] = []
tplot tortuga str = getpos tortuga : tplot (step tortuga (head str)) (tail str)
